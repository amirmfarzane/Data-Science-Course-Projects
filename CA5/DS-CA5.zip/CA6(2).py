#!/usr/bin/env python
# coding: utf-8

#    
# <div style="background-image: linear-gradient(to left, rgb(255, 255, 255), rgb(138, 136, 136)); width: auto; margin: 10px;">
#   <img src="https://upload.wikimedia.org/wikipedia/en/thumb/f/fd/University_of_Tehran_logo.svg/225px-University_of_Tehran_logo.svg.png" width=100px width=auto style="padding:10px; vertical-align: center;">
# 
# </div>
#    
# <div   style:"text-align: center; background-image: linear-gradient(to left, rgb(255, 255, 255), rgb( 219, 204, 245  ));width: 400px; height: 30px; ">
# <h1 style="font-family: Georgia; color: black; text-align: center; ">Course: Data Science </h1>
# 
# </div>
#     <div   style:"border: 3px solid green;text-align: center; ">
# <h1 style="font-family: Georgia; color: black; text-align: center; ">CA6-Introduction to Data Science</h1>
#         <h1 style="font-family: Georgia; color: black; text-align: center; ">Team memebers:</h1>
# 
# </div>
# 
# <div>    
# <h1 style="font-family: Georgia; color: black; text-align: center; font-size:15px;">Shahzad Momayez- 810100272 </h1>
# <h1 style="font-family: Georgia; color: black; text-align: center; font-size:15px;">Mohammad Amanlou- 810100084 </h1>
# <h1 style="font-family: Georgia; color: black; text-align: center; font-size:15px;">Amir Mahdi Farzaneh- 810100194 </h1>
# 
# </div>
#    </html>

# ## The purpose of the assignment:
# ....

# 
# <html> 
#     <div  style="font-family: Georgia ;background-image: linear-gradient(to left,  rgb(255, 255, 255), rgba(127, 170, 225,0.8)); width: auto; margin: 10px;"> <h1>  Part1 : Preprocessing </h1>
#     </div>
# </html>

# In[13]:


import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats
import seaborn as sns
import numpy as np
from sklearn.preprocessing import LabelEncoder
import json
from sklearn.impute import KNNImputer


# In[14]:


pd.set_option('display.max_rows', None)
df = pd.read_csv("diabetic_data.csv")
df.head(10)


# In[15]:


df.describe()


# In[16]:


df["examide"].unique()


# In[17]:


df["citoglipton"].unique()


# In[18]:


df.info()


# # handle duplication

# In[19]:


df.duplicated().sum()


# In[20]:


for column in df.select_dtypes(include=[np.number]).columns:
    df[column].plot(kind='hist', bins=20, color='purple', edgecolor='black', figsize=(10, 6))
    plt.xlabel(column)
    plt.ylabel('Frequency')
    plt.title(f'Histogram of {column} ')
    plt.show()
    


# In[21]:


for column in df.select_dtypes(include=[np.number]).columns:
    sns.boxplot(x=df[column])
    plt.title(f'Box Plot of {column}')
    plt.show()


# In[22]:


non_numerical_columns = df.select_dtypes(exclude='number').columns
category_counts = {}

for col in non_numerical_columns:
    category_counts[col] = df[col].value_counts()
    
for col, counts in category_counts.items():
    print(f"Category counts for column '{col}':")
    print(counts)
    print()


# In[23]:


df.replace("?", np.nan, inplace=True)
categorical_columns = df.select_dtypes(include=['object']).columns
categorical_columns


# In[24]:


df.isna().sum()


# # handle missing values

# In[25]:


#### use knn imputer to fill missing categorical vallues 
#race


##col = diabetic_df.select_dtypes(include=[np.number,'float']).columns.to_list()
#selected_data = diabetic_df[col]

#imputer = KNNImputer(n_neighbors=5)
#df_imputed = pd.DataFrame(imputer.fit_transform(diabetic_df), columns=diabetic_df.columns)

#print("\nDataFrame after KNN imputation:")
#df_imputed


# In[26]:


cols_with_null = ['race', 'payer_code' ,'medical_specialty' ,'diag_1','diag_2','diag_3'  ]
for col in cols_with_null:
    df[col].fillna(df[col].mode()[0], inplace=True)


# In[27]:


categorical_columns = df.select_dtypes(include=['object']).columns
le = LabelEncoder()

for col in categorical_columns:
    df[col] = le.fit_transform(df[col].astype(str))


# In[28]:


for col in non_numerical_columns:
    category_counts[col] = df[col].value_counts()
    
for col, counts in category_counts.items():
    print(f"Category counts for column '{col}':")
    print(counts)
    print()


# In[29]:


#remove columns with almost 1 value

df.drop(columns=["citoglipton","examide",'weight','metformin-pioglitazone', 'metformin-rosiglitazone', 'glimepiride-pioglitazone', 'glipizide-metformin'], inplace=True)


# # remove outliers

# In[30]:


df.describe()


# In[31]:


df["gender"].replace(2,df["gender"].mode()[0] , inplace=True)


# In[32]:


cols_with_outlier =["payer_code","diag_1","diag_2","diag3","acarbose","chlorpropamide","number_outpatient","medical_specialty","miglitol","troglitazone","metformin","glyburide-metformin"]

for col in cols_with_outlier:
    category_counts = df[col].value_counts()

    plt.hist(df[col], bins=20)  # Adjust the number of bins as needed
    plt.xlabel('Value')
    plt.ylabel('Frequency')
    plt.title(f'Histogram of {col} Column')
    plt.show()

    print(df[col].value_counts())

    threshold = 40

    rare_categories = category_counts[category_counts < threshold].index
    df = df[~ df[col].isin(rare_categories)]


    print(df[col].value_counts())


# In[ ]:


# another way remove outliers for numerical

#IQR = Q3 - Q1
#lower_limit = Q1 - 1.5 * IQR
#upper_limit = Q3 + 1.5* IQR
#df = diabetic_df[(diabetic_df.number_outpatient>lower_limit) &(diabetic_df.number_outpatient< upper_limit) ] 

#df


# In[33]:


correlation_matrix = df.corr()

plt.figure(figsize=(30, 25))
cmap = sns.diverging_palette(220, 20, as_cmap=True)
sns.heatmap(correlation_matrix, cmap=cmap, annot=True, fmt=".2f", cbar_kws={"shrink": 0.3})
plt.title('Correlation Matrix')

plt.show()


# In[ ]:


mapping_df = pd.read_csv("IDs_mapping.csv")
mapping_df


# 
# <html> 
#     <div  style="font-family: Georgia ;background-image: linear-gradient(to left,  rgb(255, 255, 255), rgba(127, 170, 225,0.8)); width: auto;height : 50px; margin: 1px; padding: 0.5px;"> <h1>  Questions: </h1>
#     </div>
#     
# </html>
# 
# <html> 
#         <hr/>
#     <div  style="font-family: Georgia ;background-image: linear-gradient(to left,  rgb(255, 255, 255), rgba(127, 170, 225,0.2)); width: auto;height : 100px; margin: 1px; padding: 0.5px;"> <h1>  Q1: What preprocessing steps did you perform on the dataset? Provide clear reasons for each decision made.</h1>
#     </div>
# 
# </html>
# 
# 
#      1. we removed columns that had so many missing values.
#      2. we removed rows that had errors or had outliers.
#      3. we handled outliers by removing or replacing them.
#      4. we encoded categorical columns.
#  
# 
#  Preprocessing a dataset is a crucial step in data analysis and machine learning, as it ensures the data is clean, consistent, and ready for modeling. Here's a detailed explanation of the common preprocessing steps that might be performed on a dataset:
# 
# ### 1. Data Cleaning
# **a. Handling Missing Values:**
# - **Removal:** Rows or columns with a significant proportion of missing values can be removed.
# - **Imputation:** Missing values can be filled using various strategies, such as mean, median, mode, or more sophisticated methods like k-nearest neighbors (KNN) or regression-based imputation.
# 
# **b. Handling Outliers:**
# - **Detection:** Identify outliers using statistical methods (e.g., Z-score, IQR) or visualization techniques (e.g., box plots).
# - **Treatment:** Outliers can be removed or transformed, depending on the context. For example, they can be capped at a certain value or replaced with the mean/median.
# 
# **c. Noise Removal:**
# - Techniques like smoothing, aggregation, or using filters (e.g., moving average) can help reduce noise in the data.
# 
# ### 2. Data Transformation
# **a. Scaling and Normalization:**
# - **Standardization:** Transform data to have a mean of zero and a standard deviation of one.
# - **Normalization:** Scale data to a range between 0 and 1 or -1 and 1, using min-max scaling or other normalization techniques.
# 
# **b. Encoding Categorical Variables:**
# - **Label Encoding:** Convert categorical labels into integer codes.
# - **One-Hot Encoding:** Create binary columns for each category.
# - **Binary Encoding:** Convert categories to binary digits.
# - **Target Encoding:** Encode categories based on the mean of the target variable.
# 
# **c. Log Transformation:**
# - Applied to skewed data to reduce skewness and make the distribution more normal-like.
# 
# **d. Polynomial Features:**
# - Create interaction terms or polynomial terms to capture non-linear relationships.
# 
# ### 3. Feature Engineering
# **a. Feature Creation:**
# - Generate new features based on existing data, such as aggregating features over time periods, creating ratios, or using domain knowledge to craft meaningful features.
# 
# **b. Feature Selection:**
# - **Filter Methods:** Select features based on statistical tests (e.g., chi-square, ANOVA).
# - **Wrapper Methods:** Use algorithms like recursive feature elimination (RFE) to select features.
# - **Embedded Methods:** Utilize regularization techniques (e.g., Lasso, Ridge) to select features during model training.
# 
# ### 4. Data Integration
# - **Merging Datasets:** Combine multiple data sources using keys or indexes to create a single comprehensive dataset.
# - **Handling Duplicates:** Identify and remove duplicate records to ensure data integrity.
# 
# ### 5. Data Reduction
# **a. Dimensionality Reduction:**
# - Techniques like Principal Component Analysis (PCA), Linear Discriminant Analysis (LDA), or t-SNE can reduce the number of features while preserving variance.
# 
# **b. Sampling:**
# - **Downsampling:** Reduce the number of samples in a large dataset.
# - **Upsampling:** Increase the number of samples in a small dataset, often used in imbalanced classification problems.
# 
# ### 6. Data Splitting
# - Split the dataset into training, validation, and test sets to ensure the model is evaluated on unseen data.
# 
# ### Example Workflow
# Here’s an example workflow combining these steps:
# 
# 1. **Data Cleaning:**
#    - Remove rows with more than 50% missing values.
#    - Impute missing values with the median.
#    - Detect and remove outliers using the IQR method.
# 
# 2. **Data Transformation:**
#    - Standardize numerical features.
#    - One-hot encode categorical variables.
# 
# 3. **Feature Engineering:**
#    - Create new features based on domain knowledge.
#    - Select top features using a combination of filter and wrapper methods.
# 
# 4. **Data Integration:**
#    - Merge data from multiple sources on a common key.
#    - Remove duplicate records.
# 
# 5. **Data Reduction:**
#    - Apply PCA to reduce dimensionality.
# 
# 6. **Data Splitting:**
#    - Split the data into 70% training, 15% validation, and 15% test sets.
# 
# By following these preprocessing steps, the dataset becomes clean, consistent, and ready for effective modeling and analysis.
# 
# <html> 
#         <hr/>
#     <div  style="font-family: Georgia ;background-image: linear-gradient(to left,  rgb(255, 255, 255), rgba(127, 170, 225,0.2)); width: auto;height : 100px; margin: 1px; padding: 0.5px;"> <h1>  Q2: What portion of the dataset did you retain during dimensionality reduction, and which variables were retained? Could you elaborate on the rationale behind this decision?
# </h1>
#     </div>
# 
# </html>
# 
# <html> 
#         <hr/>
#     <div  style="font-family: Georgia ;background-image: linear-gradient(to left,  rgb(255, 255, 255), rgba(127, 170, 225,0.2)); width: auto;height : 100px; margin: 1px; padding: 0.5px;"> <h1>  Q3: Include a plot illustrating the silhouette coefficient plotted against the input parameters for each clustering method within the report file.
#  </h1>
#     </div>
# 
# </html>
# 
# 
# <html> 
#         <hr/>
#     <div  style="font-family: Georgia ;background-image: linear-gradient(to left,  rgb(255, 255, 255), rgba(127, 170, 225,0.2)); width: auto;height : 100px; margin: 1px; padding: 0.5px;"> <h1>  Q4: How can we determine the optimal number of clusters in K-Means</h1>
#     </div>
# 
# </html>
# 
# Determining the optimal number of clusters in K-Means clustering is crucial for achieving meaningful results. Here are several methods commonly used to find the optimal number of clusters:
# 
# ### 1. Elbow Method
# The Elbow Method involves plotting the sum of squared distances from each point to its assigned cluster center (within-cluster sum of squares, or WCSS) against the number of clusters (k). The idea is to identify an "elbow point" where the rate of decrease sharply slows. This point suggests that adding more clusters beyond this does not significantly improve the model.
# 
# **Steps:**
# - Run K-Means with a range of k values (e.g., from 1 to 10).
# - Calculate the WCSS for each k.
# - Plot the WCSS against the number of clusters.
# - Look for the elbow point in the plot where the WCSS starts to flatten.
# 
# ### 2. Silhouette Analysis
# The Silhouette Score measures how similar an object is to its own cluster compared to other clusters. It ranges from -1 to 1, where a higher value indicates that the object is well matched to its own cluster and poorly matched to neighboring clusters.
# 
# **Steps:**
# - Run K-Means for a range of k values.
# - Calculate the average silhouette score for each k.
# - Plot the silhouette scores against the number of clusters.
# - Choose the k with the highest average silhouette score.
# 
# ### 3. Gap Statistic
# The Gap Statistic compares the total within intra-cluster variation for different numbers of clusters with their expected values under null reference distribution of the data. The optimal number of clusters is where this gap is the largest.
# 
# **Steps:**
# - Run K-Means for a range of k values.
# - Calculate the WCSS for each k.
# - Generate B reference datasets and calculate their WCSS.
# - Compute the gap statistic.
# - Choose the k with the maximum gap statistic.
# 
# ### 4. Davies-Bouldin Index
# The Davies-Bouldin Index evaluates the average similarity ratio of each cluster with its most similar cluster. Lower values indicate better clustering.
# 
# **Steps:**
# - Run K-Means for a range of k values.
# - Calculate the Davies-Bouldin Index for each k.
# - Plot the index against the number of clusters.
# - Choose the k with the lowest Davies-Bouldin Index.
# 
# ### 5. Bayesian Information Criterion (BIC) / Akaike Information Criterion (AIC)
# BIC and AIC can be used in the context of Gaussian Mixture Models (GMM), which is a probabilistic model related to K-Means. These criteria balance model fit and complexity.
# 
# **Steps:**
# - Fit a GMM for a range of k values.
# - Calculate the BIC and AIC for each k.
# - Plot BIC and AIC against the number of clusters.
# - Choose the k with the lowest BIC or AIC.
# 
# ### Practical Considerations
# - **Domain Knowledge**: Incorporate any domain-specific knowledge about the data to guide the selection of k.
# - **Visual Inspection**: Use visual methods like plotting clusters to see if the clusters make sense.
# - **Stability**: Check the stability of the clustering by running the algorithm multiple times and ensuring consistent results.
# 
# Using a combination of these methods can provide a more robust determination of the optimal number of clusters.
# 
# 
# <html> 
#         <hr/>
#     <div  style="font-family: Georgia ;background-image: linear-gradient(to left,  rgb(255, 255, 255), rgba(127, 170, 225,0.2)); width: auto;height : 100px; margin: 1px; padding: 0.5px;"> <h1>  Q5: How can we determine the optimal epsilon value and minPts in DBSCAN?
# </h1>
#     </div>
# 
# </html>
# Determining the optimal parameters \( \epsilon \) (epsilon) and \( \text{minPts} \) (minimum points) in DBSCAN (Density-Based Spatial Clustering of Applications with Noise) is crucial for achieving effective clustering. Here are several methods to find these parameters:
# 
# ### 1. Determining \( \epsilon \)
# The parameter \( \epsilon \) defines the maximum distance between two points to be considered neighbors. One common approach to find an appropriate value for \( \epsilon \) is to use the **k-distance graph**.
# 
# **Steps:**
# 1. **Calculate k-distances**: Compute the distance from each point to its \( k \)-th nearest neighbor. A common choice for \( k \) is the same value as \(\text{minPts}\).
# 2. **Plot the k-distances**: Sort these distances in ascending order and plot them.
# 3. **Find the "knee" point**: Look for the "knee" or "elbow" point in the plot, where the k-distance starts to increase rapidly. This point is a good candidate for \( \epsilon \).
# 
# ### 2. Determining \(\text{minPts}\)
# The parameter \(\text{minPts}\) defines the minimum number of points required to form a dense region.
# 
# **Guidelines for \(\text{minPts}\)**:
# - **Rule of thumb**: A common heuristic is \(\text{minPts} = 2 \times \text{dim}\), where \(\text{dim}\) is the number of dimensions in the dataset. For example, in a 2-dimensional dataset, \(\text{minPts} = 4\).
# - **Data characteristics**: If the dataset has noise or is more spread out, a higher \(\text{minPts}\) might be required.
# - **Domain knowledge**: Consider the domain knowledge to select \(\text{minPts}\). For example, in social networks, clusters might represent groups of at least 5 people, so \(\text{minPts} = 5\).
# 
# ### 3. Iterative Approach
# Often, it is beneficial to use an iterative approach to refine both \(\epsilon\) and \(\text{minPts}\):
# 
# **Steps**:
# 1. **Initial estimation**:
#    - Use the k-distance plot to estimate \(\epsilon\).
#    - Choose an initial \(\text{minPts}\) based on the rule of thumb or domain knowledge.
# 2. **Run DBSCAN**:
#    - Perform DBSCAN with the chosen \(\epsilon\) and \(\text{minPts}\).
# 3. **Evaluate results**:
#    - Examine the resulting clusters. Check for the presence of too many noise points or overly large/small clusters.
#    - Adjust \(\epsilon\) and \(\text{minPts}\) based on the clustering outcome and repeat the process.
# 
# ### 4. Silhouette Analysis for DBSCAN
# Silhouette analysis can be adapted for DBSCAN to evaluate different parameter choices:
# 
# **Steps**:
# 1. **Run DBSCAN** with different combinations of \(\epsilon\) and \(\text{minPts}\).
# 2. **Calculate silhouette scores**: Compute the silhouette score for each clustering result. The silhouette score measures how similar each point is to its own cluster compared to other clusters.
# 3. **Choose optimal parameters**: Select the combination of \(\epsilon\) and \(\text{minPts}\) that maximizes the average silhouette score.
# 
# ### 5. Grid Search
# Conduct a grid search over a range of \(\epsilon\) and \(\text{minPts}\) values to find the optimal combination:
# 
# **Steps**:
# 1. **Define ranges** for \(\epsilon\) and \(\text{minPts}\).
# 2. **Run DBSCAN** for each combination of parameters within these ranges.
# 3. **Evaluate clustering results**: Use evaluation metrics such as the number of clusters, the percentage of noise points, and domain-specific validation methods.
# 4. **Select the best parameters**: Choose the parameters that yield the best performance according to the chosen metrics.
# 
# ### Practical Considerations
# - **Noise**: High noise levels in the dataset might require higher \(\text{minPts}\) or different \(\epsilon\) values.
# - **Data scale**: Standardize or normalize the data if features have different scales to ensure that \(\epsilon\) is meaningful.
# - **Domain knowledge**: Incorporate domain knowledge to guide parameter selection.
# 
# By combining these methods, you can systematically determine the optimal \(\epsilon\) and \(\text{minPts}\) values for DBSCAN, leading to more meaningful clustering results.
# 
# 
# <html> 
#         <hr/>
#     <div  style="font-family: Georgia ;background-image: linear-gradient(to left,  rgb(255, 255, 255), rgba(127, 170, 225,0.2)); width: auto;height : 100px; margin: 1px; padding: 0.5px;"> <h1>  Q6: When would you recommend using K-Means, and when would you suggest using DBSCAN instead?
# 
# </h1>
#     </div>
# 
# </html>
# 
# 
# Choosing between K-Means and DBSCAN depends on the characteristics of your dataset and the specific requirements of your clustering task. Here are some guidelines to help decide which algorithm to use:
# 
# ### When to Use K-Means
# 
# 1. **Well-Defined, Spherical Clusters**:
#    - K-Means is best suited for datasets where the clusters are spherical or convex in shape. It works well when clusters are relatively equally sized and have similar densities.
# 
# 2. **Large, Homogeneous Data**:
#    - K-Means can handle large datasets efficiently, especially when clusters are roughly similar in size and density.
# 
# 3. **Low-Dimensional Data**:
#    - K-Means performs well on low-dimensional data where the concept of distance (e.g., Euclidean distance) is meaningful.
# 
# 4. **Speed and Scalability**:
#    - K-Means is computationally efficient and scales well to large datasets. It has a linear time complexity with respect to the number of data points.
# 
# 5. **Known Number of Clusters (k)**:
#    - K-Means requires the number of clusters (k) to be specified in advance. Use K-Means when you have a good estimate of the number of clusters.
# 
# 6. **Smooth Cluster Boundaries**:
#    - If clusters have smooth and clear boundaries, K-Means is likely to perform well.
# 
# ### When to Use DBSCAN
# 
# 1. **Arbitrary Shaped Clusters**:
#    - DBSCAN excels at identifying clusters of arbitrary shapes, including elongated or irregularly shaped clusters. It does not assume spherical clusters.
# 
# 2. **Handling Noise and Outliers**:
#    - DBSCAN can effectively identify and handle noise points, labeling them as outliers. This is useful for datasets with a significant amount of noise.
# 
# 3. **Varying Density Clusters**:
#    - DBSCAN can find clusters of varying densities, making it suitable for datasets where clusters have different densities.
# 
# 4. **No Need for Predefined Number of Clusters**:
#    - DBSCAN does not require specifying the number of clusters in advance. It discovers the number of clusters based on the density of points.
# 
# 5. **High-Dimensional Data**:
#    - DBSCAN can be effective for high-dimensional data, though the choice of distance metric and parameter tuning becomes more challenging.
# 
# 6. **Non-Linearly Separable Data**:
#    - When clusters are not linearly separable, DBSCAN can be a better choice as it can find clusters based on density rather than distance alone.
# 
# ### Practical Scenarios
# 
# #### Use K-Means If:
# - You have a large dataset with roughly spherical, equally sized clusters.
# - You know the approximate number of clusters in advance.
# - Your data is low-dimensional, and computational efficiency is a priority.
# - You are looking for a simple, fast algorithm to partition your data into clusters.
# 
# #### Use DBSCAN If:
# - Your clusters have arbitrary shapes and are not well-separated.
# - Your data contains noise and outliers, and you want the algorithm to identify and exclude them.
# - You do not know the number of clusters in advance.
# - Your data has varying densities across clusters.
# - You are dealing with spatial data or data that naturally forms density-based clusters.
# 
# ### Examples
# 
# - **K-Means**:
#   - Customer segmentation based on purchasing behavior where clusters are expected to be spherical.
#   - Grouping similar images based on pixel values in image processing tasks where the number of groups is predefined.
# 
# - **DBSCAN**:
#   - Identifying geographic regions of different population densities from spatial data.
#   - Clustering gene expression data where clusters have irregular shapes and there is noise in the data.
# 
# By considering these guidelines and the specific characteristics of your dataset, you can choose the clustering algorithm that is best suited for your needs.
# 

# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




